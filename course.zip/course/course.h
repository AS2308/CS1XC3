/**
 * @file course.h
 * @author Audry Surendra
 * @date 12 Apr 2022
 * @brief Header file containing information about courses.
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * Course type stores a course with fields name, code, students, and total students 
 * 
 */

typedef struct _course 
{
  char name[100]; /**< the course's name */
  char code[10]; /**< the course's code */
  Student *students; /**< the students enrolled in the course */
  int total_students; /**< the course's total number of students enrolled */
} Course;

void enroll_student(Course *course, Student *student); // enrolls a student in the course
void print_course(Course *course); // prints out details of the course
Student *top_student(Course* course); // determines the student with the highest grade in the course
Student *passing(Course* course, int *total_passing); // determines the total number of students passing the course


