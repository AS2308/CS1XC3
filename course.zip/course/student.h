/**
 * @file student.h
 * @author Audry Surendra
 * @date 12 Apr 2022
 * @brief Header file containing information about students.
 */ 


/**
 * Student type stores a student with fields first_name, last_name, id, grades, and num_grades. 
 * 
 */

typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11]; /**< the student's 11 digit id */
  double *grades; /**< the student's grades as a list */
  int num_grades; /**< the numer of grades the student has */
} Student;

void add_grade(Student *student, double grade); // function to add a grade to the student's list of grades
double average(Student *student); // function to determine the student's average
void print_student(Student *student); // function to print out the student's information
Student* generate_random_student(int grades); // function to generate a random student
