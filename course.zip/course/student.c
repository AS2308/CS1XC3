/**
 * @file student.c
 * @author Audry Surendra
 * @date 12 Apr 2022
 * @brief C file containing information about students.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * Adds a grade to a student's record. If the student only has one grade,
 * then an array of size 1 is created to store the student's grades using calloc;
 * otherwise realloc is used to increase the size of the array and make
 * room to add another grade, and the new grade is added to the array.
 * 
 * @param student the student represented as a pointer
 * @param grade the student's grade represented as a double
 * @return nothing
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * Finds the average grade of the student by looping through the
 * list of their grades, and taking the average of its sum. 
 * 
 * @param student the student represented as a pointer
 * @return a double
 */

double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * Prints out the student's information. Prints out their name and id, uses a
 * for loop to print each of their grades, and uses the average function
 * to determine and subsequently print their average. 
 * 
 * @param student the student represented as a pointer
 * @return nothing
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * Generates a random student. A list of first and last names are 
 * created; then, a first and last name are randomly selected from the lists,
 * a random 11 digit student id is generated, and finally a random grade is 
 * generated and added to the student with the add_grade function.
 * 
 * @param grades the student's grades represented as an integer
 * @return a student
 */

Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  // copies a randomly selected first and last name into the new_student
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // generates a random number from 1-10 eleven times to generate a random 11 digit id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75))); 
  }

  return new_student;
}