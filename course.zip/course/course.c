/**
 * @file course.c
 * @author Audry Surendra
 * @date 12 Apr 2022
 * @brief C file containing information about courses.
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * Enrolls a student in a course by adding their name to the list of students belonging to the course
 * If the course only has one student, the function allocates a memory of size 1 
 * to the list of students for the course using calloc.
 * Otherwise, the function uses realloc to increase the list of students by 1 
 * so that the current student can be added to the list.
 * 
 * @param course the course represented as a pointer
 * @param student the student represented as a pointer
 * @return nothing
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * Prints the name, code, and total students in a given course.
 * The function then prints each student by looping through
 * the list of students belonging to the course and using the
 * print_student function to print them all out.
 * 
 * @param course the course represented as a pointer
 * @return nothing
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * Returns the student in a given course with the highest average.
 * If there are no students in the course, return NULL;
 * else, the function loops through each student in the list
 * and gets their average, placing it as the max average if it
 * is the highest number so far in the loop. 
 * 
 * @param course the course represented as a pointer
 * @return student 
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * Determines the number of students passing the course.
 * Loops through the students to determine how many are passing 
 * and allocate that much memory to an array, then loop through the 
 * students once more to assign the students passing to the array.
 * 
 * @param course the course represented as a pointer
 * @param total_passing the total number of students passing, represented as a pointer
 * @return student 
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  
  for (int i = 0; i < course->total_students; i++) 
    // if the user's average is greater than 50%, then they're passing
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}